using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI; // Add this line

public class QuizManager : MonoBehaviour
{
    public List<QuestionsAndAnswers> QnA;
    public GameObject[] options;
    public int currentQuestion; // Corrected variable name

    public Text QuestionTxt;

    private void Start()
    {
        generateQuesion(); // Corrected function name
    }

    void SetAnswers()
    {
        for (int i = 0; i < options.Length; i++)
        {
            options[i].transform.GetChild(0).GetComponent<Text>().text = QnA[currentQuestion].Answers[i];
        }
    }

void generateQuesion()
{
    if(QnA == null || QnA.Count == 0)
    {
        Debug.LogError("QnA list is empty or null!");
        return;
    }

    currentQuestion = Random.Range(0, QnA.Count);

    QuestionTxt.text = QnA[currentQuestion].Question;
}

    public DynamicLightingController lightingController;  // Reference to the lighting controller script

    // Simulated function to handle quiz answers
    public void OnAnswerSelected(bool isCorrect)
    {
        if (isCorrect)
        {
            // Call the lighting function for a correct answer
            lightingController.HighlightOnCorrectAnswer();
        }
        else
        {
            // Call the lighting function for an incorrect answer
            lightingController.HighlightOnError();
        }

        // Reset the lighting after a delay
        Invoke("ResetLighting", 2.0f);
    }

    // Reset the lighting back to default
    void ResetLighting()
    {
        lightingController.ResetLighting();
    }

}
